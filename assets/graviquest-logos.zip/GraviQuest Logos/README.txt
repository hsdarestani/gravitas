GRAVIQUEST LOGO PACK
====================

"Logo" is the mark: two quarter-rings on a square.
"Logotype" is the mark with the wordmark, GraviQuest.

Logotype_White.svg   The mark and the wordmark, White #FFFFFF. viewBox 581.23 x 100.
Logo_White.svg       The mark alone, White #FFFFFF. viewBox 100 x 100.
Pulsar_White.svg     Pulsar, the assistant's mark, White #FFFFFF. viewBox 100 x 100.
Favicon.svg          The mark in white on a Cosmos Blue disc, for favicons and avatars.

These files are the source. The website draws no other copy of the
geometry: every header, footer and specimen masks these same files and
paints them with currentColor, so the mark follows the page theme. The
files are white so they are visible when opened on their own; the colour
on the site comes from the page, not from the file.

THE MARK
  Each quarter-ring is centred on one corner of the square, with its
  centre line at half the side. Its width is (sqrt 2 - 1) / 2 of the side,
  20.71 units, which is also the gap the two rings leave between them on
  the diagonal. Pulsar repeats the quarter-ring on all four corners around
  a solid dot.

COLOURS
  White   #f1efec   on Cosmos Blue, Royal Black or space imagery. Most common.
  Blue    #003049   on White Tint, Sisal or any light background.
  Black   #030303   single-colour reproduction and very light print.
  Sisal   #d4c9be   rare, for tonal work and watermarks on dark.

  Recolour by changing the fill, not by keeping a second file.

RULES
  Do not rebuild the wordmark in a font or retype it. Do not stretch,
  rotate, recolour outside the palette, or add effects to the mark itself.
  Clear space: the cap height of the G around the logotype, 25% of the
  mark's width around the mark. Minimum size: logotype 120px wide, mark
  24px. Below that, use the mark alone.

Full guidance: https://graviquest.com/brand.html
