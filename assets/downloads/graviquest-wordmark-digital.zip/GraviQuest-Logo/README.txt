GRAVIQUEST LOGO PACK
====================

LOGO VARIATIONS
  01 Vertical Logo     The two-line logotype: Gravi over Quest.
  02 Horizontal Logo   The mark and the wordmark on one line. The primary logo.
  03 Brandmark         The mark alone: two quarter-rings on a square.
  04 Wordmark          GraviQuest without the mark.
  05 Profile Pictures  Instagram, Telegram and Pulsar avatars (see below).

COLOUR SPACES
  01 Digital   RGB. Screens, web, video, slides.
               SVG, PNG (transparent), JPEG, plus AI, PDF and EPS.
  02 Print     CMYK. Anything printed. AI, PDF (PDF/X-4), EPS, plus
               CMYK JPEG and PNG at 300 ppi. No SVG: it is a screen format.

COLOUR VARIATIONS
                  Digital (RGB)               Print (CMYK)
  01 Full-Colour  Cosmos Blue #003049         C100 M76 Y46 K44
                  for white and light backgrounds.
  02 Inverse      White Tint #F1EFEC on a     C4 M4 Y5 K0 on
                  Cosmos Blue field           C100 M76 Y46 K44
                  the logo with its own blue background, for when it
                  has to carry its own ground.
  03 Black        Royal Black #030303         K100
                  single-colour work, light backgrounds.
  04 White        #FFFFFF                     no ink (paper white)
                  for dark backgrounds and imagery.

  PNG files are transparent except the Inverse, which carries its field.
  JPEG has no transparency, so each sits on a ground: white under
  Full-Colour and Black, Cosmos Blue under White.

  The CMYK values are Illustrator's own conversion of the brand RGB. Ask
  the printer to proof Cosmos Blue against #003049 before a large run.

SIZES
  Rasters, digital and print alike:
    Horizontal and Wordmark   4000 px wide
    Vertical                  3000 px wide
    Brandmark                 2000 x 2000 px
  Print rasters are 300 ppi, which makes the horizontal logo print about
  34 cm wide at full resolution. Vector files scale to any size.

  Every file has a margin of a quarter of the logo's height on all sides,
  measured from the letters: cap height to baseline. The tail of the Q is
  not counted, so the letters sit on the vertical centre and the tail
  hangs into the bottom margin. Use the same rule when placing the logo.

PROFILE PICTURES (2048 x 2048, square, full bleed; platforms crop to a circle)
  Instagram   The vertical logo, white on Cosmos Blue, centred on its
              letters with the Q's tail ignored.
  Telegram    The mark alone, white on Cosmos Blue, at half the frame.
  Pulsar      Pulsar's mark in Cosmos Blue on Sisal #D4C9BE, at half the
              frame. Sisal is the brand's accent, and it keeps the
              assistant's avatar distinct from GraviQuest's blue ones.

RULES
  Do not retype the wordmark, stretch, rotate, mirror, recolour outside
  the palette, or add effects to the mark. Minimum size: logotype 120 px
  wide, mark 24 px. Below that, use the mark alone.

Full guidance: https://graviquest.com/brand.html
