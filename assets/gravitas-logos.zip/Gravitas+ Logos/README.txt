GRAVITAS+ LOGO PACK
===================

"Logo" is the monogram, the faceted G.
"Logotype" is the full wordmark, Gravitas+.

Logotype_Black.svg   The wordmark, Black #030303.
Logo_Black.svg       The monogram, Black #030303.

These two files are the source. The website draws no other copy of the
geometry: every header, footer and specimen masks these same files and
paints them with currentColor, so the mark follows the page theme.

COLOURS
  White   #f1efec   on Cosmos Blue, Royal Black or space imagery. Most common.
  Blue    #003049   on White Tint, Sisal or any light background.
  Black   #030303   single-colour reproduction and very light print.
  Sisal   #d4c9be   rare, for tonal work and watermarks on dark.

  Recolour by changing the fill, not by keeping a second file.

RULES
  Keep the plus. Do not rebuild the wordmark in a font. Do not stretch,
  rotate, recolour outside the palette, or add effects to the mark itself.
  Clear space: the cap height of the G around the logotype, 25% of the icon
  width around the monogram. Minimum size: logotype 120px wide, monogram
  24px. Below that, use the monogram.

Full guidance: /brand
